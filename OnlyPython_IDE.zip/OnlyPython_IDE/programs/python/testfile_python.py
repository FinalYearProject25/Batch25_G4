a = int(input())
b = int(input())

print("Enter first number: ", a)
print("Enter second number: ", b)

if b > a:
  print(b-a)
else:
  print(a-b)																			